﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace W14_Bernard_INSERT_CA
{
    public partial class Form1 : Form
    {
        MySqlDataAdapter sqldataadapter;
        MySqlConnection sqlconnect;
        MySqlCommand sqlcommand;
        public Form1()
        {
            InitializeComponent();
        }
        
        List <string> team = new List<string>();
        int a = 0;
        DataTable date = new DataTable();
        DataTable dgv = new DataTable();
        DataTable tim = new DataTable();
        DataTable dmatch = new DataTable();
        DataTable player = new DataTable();
        bool tes = false;
        private void Form1_Load(object sender, EventArgs e)
        {
            dgv.Columns.Add("minute");
            dgv.Columns.Add("Team");
            dgv.Columns.Add("Player");
            dgv.Columns.Add("Type");

            dmatch.Columns.Add("match_id");
            dmatch.Columns.Add("minute");
            dmatch.Columns.Add("team_id");
            dmatch.Columns.Add("player_id");
            dmatch.Columns.Add("Type");


            sqlconnect = new MySqlConnection("server=localhost;uid=root;pwd=Bernardo1777*;database=premier_league");
            string sql = "select team_name, team_id from team";
            sqlcommand = new MySqlCommand(sql, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);

            DataTable teamaway = new DataTable();
            sqldataadapter.Fill(teamaway);
            cb_teamaway.DataSource = teamaway;
            cb_teamaway.DisplayMember = "team_name";
            cb_teamaway.ValueMember = "team_id";
            cb_teamaway.Text = "";

            DataTable teamhome = new DataTable();
            sqldataadapter.Fill(teamhome);
            cb_teamhome.DataSource = teamhome;
            cb_teamhome.DisplayMember = "team_name";
            cb_teamhome.ValueMember = "team_id";
            cb_teamhome.Text = "";

            string matchid = "select match_date, LEFT(match_id,4) from `match`";
            sqlcommand = new MySqlCommand(matchid, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);
            sqldataadapter.Fill(date);
            dateTimePicker2.Text = date.Rows[date.Rows.Count - 1][0].ToString();
            tanggalan();

            tim.Columns.Add("team_name");
            tim.Columns.Add("team_id");
        }
        int cek = 0;
        private void cb_teamhome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cek > 3)
            {
                if (cb_teamaway.Text == cb_teamhome.Text)
                {
                    MessageBox.Show("Team Gaboleh Sama");
                    cb_teamhome.Text = "";
                    cb_teamaway.Text = "";
                    tim.Rows.Clear();
                    player.Rows.Clear();
                }
                if (cb_teamaway.Text != "" && cb_teamhome.Text != "")
                {
                    tim.Rows.Clear();
                    tim.Rows.Add(cb_teamhome.Text, cb_teamhome.SelectedValue);
                    tim.Rows.Add(cb_teamaway.Text, cb_teamaway.SelectedValue);
                    cb_team.DataSource = tim;
                    cb_team.DisplayMember = "team_name";
                    cb_team.ValueMember = "team_id";
                    player.Rows.Clear();
                }
            }
            cek++;
        }

        private void cb_teamaway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cek > 3)
            {
                if (cb_teamaway.Text == cb_teamhome.Text)
                {
                    MessageBox.Show("Team Gaboleh Sama");
                    cb_teamhome.Text = "";
                    cb_teamaway.Text = "";
                    tim.Rows.Clear();
                    player.Rows.Clear();
                }
                if (cb_teamaway.Text != "" && cb_teamhome.Text != "")
                {
                    tim.Rows.Clear();
                    tim.Rows.Add(cb_teamhome.Text, cb_teamhome.SelectedValue);
                    tim.Rows.Add(cb_teamaway.Text, cb_teamaway.SelectedValue);
                    cb_team.DataSource = tim;
                    cb_team.DisplayMember = "team_name";
                    cb_team.ValueMember = "team_id";
                    player.Rows.Clear();
                }
            }
            cek++;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            tanggalan();

            if (dateTimePicker1.Value.Year == dateTimePicker2.Value.Year)
            {
                if (dateTimePicker1.Value.Month == dateTimePicker2.Value.Month)
                {
                    if (dateTimePicker1.Value.Day < dateTimePicker2.Value.Day)
                    {
                        tb_matchid.Text = "";
                        MessageBox.Show("Tanggal Harus diatasnya");
                    }
                }
                else if (dateTimePicker1.Value.Month < dateTimePicker2.Value.Month)
                {
                    tb_matchid.Text = "";
                    MessageBox.Show("Bulan Harus diatasnya");
                }
            }
            else if (dateTimePicker1.Value.Year < dateTimePicker2.Value.Year)
            {
                tb_matchid.Text = "";
                MessageBox.Show("Tahun Harus diatasnya");
            }
        }

        public void tanggalan()
        {
            int id = 0;
            string idd = "";

            for (int i = 0; i < date.Rows.Count; i++)
            {
                if (dateTimePicker1.Value.Year == Convert.ToInt32(date.Rows[i][1].ToString()))
                {
                    id++;
                }
            }
            id++;
            if (id < 10)
            {
                idd = "00" + id.ToString();
            }
            else if (id < 100)
            {
                idd = "0" + id.ToString();
            }
            else
            {
                idd = id.ToString();
            }
            tb_matchid.Text = dateTimePicker1.Value.Year.ToString() + idd;
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sqll = $"select player_name, player_id from player p, team t where '{cb_team.SelectedValue}' = p.team_id group by 1, 2;";
            sqlcommand = new MySqlCommand(sqll, sqlconnect); 
            sqldataadapter = new MySqlDataAdapter(sqlcommand);

            sqldataadapter.Fill(player);
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player_name";
            cb_player.ValueMember = "player_id";
        }

        private void b_add_Click(object sender, EventArgs e)
        {
            if (tb_minute.Text != "" && cb_team.Text != "" && cb_player.Text != "" && cb_type.Text != "")
            {
                cb_teamaway.Enabled = false;
                cb_teamhome.Enabled = false;
                dateTimePicker1.Enabled = false;

                dmatch.Rows.Add(tb_matchid.Text, tb_minute.Text, cb_team.SelectedValue, cb_player.SelectedValue, cb_type.Text);
                dgv.Rows.Add(tb_minute.Text, cb_team.Text, cb_player.Text, cb_type.Text);
                dataGridView1.DataSource = dgv;
                dataGridView1.ClearSelection();
            }
            else
            {
                MessageBox.Show("BELUM LENGKAP BOS");
            }
        }

        private void b_delete_Click(object sender, EventArgs e)
        {
            if (tes == true)
            {
                int index = dataGridView1.CurrentRow.Index;
                dgv.Rows.RemoveAt(index);
                dmatch.Rows.RemoveAt(index);
                tes = false;
                dataGridView1.ClearSelection();
            }
        }

        private void b_insert_Click(object sender, EventArgs e)
        {
            int goalhome = 0;
            int goalaway = 0;

            for (int i = 0; i < dgv.Rows.Count; i++)
            {
                if (dgv.Rows[i][1].ToString() == cb_teamhome.Text)
                {
                    if (dgv.Rows[i][3].ToString() == "GO" || dgv.Rows[i][3].ToString() == "GP")
                    {
                        goalhome++;
                    }
                    else if (dgv.Rows[i][3].ToString() == "GW")
                    {
                        goalaway++;
                    }
                }
                else if (dgv.Rows[i][1].ToString() == cb_teamaway.Text)
                {
                    if (dgv.Rows[i][3].ToString() == "GO" || dgv.Rows[i][3].ToString() == "GP")
                    {
                        goalaway++;
                    }
                    else if (dgv.Rows[i][3].ToString() == "GW")
                    {
                        goalhome++;
                    }
                }
            }

            string datee = "";
            if (dateTimePicker1.Value.Month < 10 && dateTimePicker1.Value.Day < 10)
            {
                datee = $"{dateTimePicker1.Value.Year.ToString()}-0{dateTimePicker1.Value.Month.ToString()}-0{dateTimePicker1.Value.Day.ToString()}";
            }
            else if (dateTimePicker1.Value.Month < 10 && dateTimePicker1.Value.Day > 9)
            {
                datee = $"{dateTimePicker1.Value.Year.ToString()}-0{dateTimePicker1.Value.Month.ToString()}-{dateTimePicker1.Value.Day.ToString()}";
            }
            else if (dateTimePicker1.Value.Month > 9 && dateTimePicker1.Value.Day < 10)
            {
                datee = $"{dateTimePicker1.Value.Year.ToString()}-{dateTimePicker1.Value.Month.ToString()}-0{dateTimePicker1.Value.Day.ToString()}";
            }
            else if (dateTimePicker1.Value.Month > 9 && dateTimePicker1.Value.Day > 9)
            {
                datee = $"{dateTimePicker1.Value.Year.ToString()}-{dateTimePicker1.Value.Month.ToString()}-{dateTimePicker1.Value.Day.ToString()}";
            }

            for (int i = 0; i < dmatch.Rows.Count; i++)
            {
                string query = $"INSERT INTO dmatch VALUES ('{dmatch.Rows[i][0].ToString()}','{dmatch.Rows[i][1].ToString()}','{dmatch.Rows[i][2].ToString()}','{dmatch.Rows[i][3].ToString()}','{dmatch.Rows[i][4].ToString()}','0')";
                sqlconnect.Open();
                sqlcommand = new MySqlCommand(query, sqlconnect);
                sqlcommand.ExecuteNonQuery();
                sqlconnect.Close();
            }

            string queryy = $"INSERT INTO `match` VALUES ('{tb_matchid.Text}'," +
                $"'{datee}'," +
                $"'{cb_teamhome.SelectedValue}'," +
                $"'{cb_teamaway.SelectedValue}'," +
                $"'{goalhome}'," +
                $"'{goalaway}'," +
                $"'M002','0')";
            sqlconnect.Open();
            sqlcommand = new MySqlCommand(queryy, sqlconnect);
            sqlcommand.ExecuteNonQuery();
            sqlconnect.Close();

            cb_teamaway.Enabled = true;
            cb_teamhome.Enabled = true;
            dateTimePicker1.Enabled = true;

            dgv.Rows.Clear();
            dmatch.Rows.Clear();

            date.Rows.Clear();
            string matchid = "select match_date, LEFT(match_id,4) from `match`";
            sqlcommand = new MySqlCommand(matchid, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);
            sqldataadapter.Fill(date);
            dateTimePicker2.Text = date.Rows[date.Rows.Count - 1][0].ToString();

            tanggalan();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tes = true;
        }

        private void tb_minute_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
